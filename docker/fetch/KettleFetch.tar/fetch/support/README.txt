Local copy of cmdr framework, revision [d46922cc52]
Manual package index file.

=== 2014-01-30 ===
18:09:43 [f1bb89c324] *CURRENT* Fixed command scope problems in "extend".
         (user: andreask tags: trunk)
18:09:12 [3a146bdf51] Fixed missing initialization in the main help generator.
         (user: andreask tags: trunk)
