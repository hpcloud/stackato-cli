#!/bin/sh

rm -rf X.* tests/*.out tests/*.err tests/thehome

