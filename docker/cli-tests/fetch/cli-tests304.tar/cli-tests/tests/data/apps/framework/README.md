# Node.js ENV 

A simple demo that prints the server's environment variables.

## Local development

    node app.js

## Deploying to Stackato

    stackato push -n
